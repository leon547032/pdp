import org.apache.poi.sl.usermodel.SlideShow;
import org.apache.poi.sl.usermodel.Slide;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;

public class PptToPdfConverter {

    public static void convertPptxToPdf(String pptxFilePath, String pdfFilePath) throws Exception {
        try (FileInputStream inputStream = new FileInputStream(pptxFilePath);
             XMLSlideShow ppt = new XMLSlideShow(inputStream);
             PDDocument pdfDocument = new PDDocument()) {

            Dimension pageSize = ppt.getPageSize();
            for (XSLFSlide slide : ppt.getSlides()) {
                BufferedImage image = new BufferedImage(pageSize.width, pageSize.height, BufferedImage.TYPE_INT_RGB);
                Graphics2D graphics = image.createGraphics();
                graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                graphics.setColor(Color.WHITE);
                graphics.fillRect(0, 0, pageSize.width, pageSize.height);
                slide.draw(graphics);
                
                // PDF 페이지 생성
                PDPage pdfPage = new PDPage();
                pdfDocument.addPage(pdfPage);

                // 이미지를 PDF로 변환
                PDImageXObject pdImage = PDImageXObject.createFromByteArray(pdfDocument,
                        imageToByteArray(image), "slide");
                try (PDPageContentStream contentStream = new PDPageContentStream(pdfDocument, pdfPage)) {
                    contentStream.drawImage(pdImage, 0, 0, pdfPage.getMediaBox().getWidth(), pdfPage.getMediaBox().getHeight());
                }
            }
            pdfDocument.save(pdfFilePath);
        }
    }

    private static byte[] imageToByteArray(BufferedImage image) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(image, "png", baos);
        return baos.toByteArray();
    }

    public static void main(String[] args) {
        try {
            convertPptxToPdf("example.pptx", "output.pdf");
            System.out.println("PPTX to PDF conversion completed!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
