package com.example.entity;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "RRS_REQ_INFO")
public class RrsReqInfo {

    @Id
    @EqualsAndHashCode.Include
    @Column(name = "RRS_REQ_SEQNO")
    private Long reqSeqNo;

    @Column(name = "TITLE")
    private String title;
}
