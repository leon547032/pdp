package com.example.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Entity
@Table(name = "RRS_SCH_INFO")
public class RrsSchInfo {

    @EmbeddedId
    private RrsSchInfoId id;

    @MapsId("reqSeqNo")
    @ManyToOne
    @JoinColumn(name = "RRS_REQ_SEQNO")
    private RrsReqInfo reqInfo;

    @Column(name = "SCHEDULE_STATUS")
    private String scheduleStatus;

    @Getter
    @Setter
    @Embeddable
    public static class RrsSchInfoId implements Serializable {

        @Column(name = "RRS_REQ_SEQNO")
        private Long reqSeqNo;

        @Column(name = "MAKE_DEGREE")
        private Integer makeDegree;

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof RrsSchInfoId)) return false;
            RrsSchInfoId that = (RrsSchInfoId) o;
            return Objects.equals(reqSeqNo, that.reqSeqNo) &&
                   Objects.equals(makeDegree, that.makeDegree);
        }

        @Override
        public int hashCode() {
            return Objects.hash(reqSeqNo, makeDegree);
        }
    }
}
