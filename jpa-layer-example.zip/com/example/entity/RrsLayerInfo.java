package com.example.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@Entity
@Table(name = "RRS_LAYER_INFO")
public class RrsLayerInfo {

    @EmbeddedId
    private RrsLayerInfoId id;

    @ManyToOne
    @JoinColumn(name = "RRS_REQ_SEQNO", insertable = false, updatable = false)
    private RrsReqInfo reqInfo;

    @ManyToOne
    @JoinColumns({
        @JoinColumn(name = "RRS_REQ_SEQNO", referencedColumnName = "RRS_REQ_SEQNO", insertable = false, updatable = false),
        @JoinColumn(name = "MAKE_DEGREE", referencedColumnName = "MAKE_DEGREE", insertable = false, updatable = false)
    })
    private RrsSchInfo schInfo;

    @Column(name = "LAYER_NAME")
    private String layerName;

    @Getter
    @Setter
    @Embeddable
    public static class RrsLayerInfoId implements Serializable {

        @Column(name = "RRS_REQ_SEQNO")
        private Long reqSeqNo;

        @Column(name = "MAKE_DEGREE")
        private Integer makeDegree;

        @Column(name = "LAYER_ID")
        private Long layerId;

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof RrsLayerInfoId)) return false;
            RrsLayerInfoId that = (RrsLayerInfoId) o;
            return Objects.equals(reqSeqNo, that.reqSeqNo) &&
                   Objects.equals(makeDegree, that.makeDegree) &&
                   Objects.equals(layerId, that.layerId);
        }

        @Override
        public int hashCode() {
            return Objects.hash(reqSeqNo, makeDegree, layerId);
        }
    }
}
