package com.example.service;

import com.example.dto.RrsLayerWithReqAndSchDTO;
import com.example.repository.RrsLayerInfoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class LayerService {

    private final RrsLayerInfoRepository layerInfoRepository;

    public List<RrsLayerWithReqAndSchDTO> getLayerInfos() {
        return layerInfoRepository.findLayerWithReqAndSch();
    }
}
