package com.example.repository;

import com.example.dto.RrsLayerWithReqAndSchDTO;
import com.example.entity.RrsLayerInfo;
import com.example.entity.RrsLayerInfo.RrsLayerInfoId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface RrsLayerInfoRepository extends JpaRepository<RrsLayerInfo, RrsLayerInfoId> {

    @Query("SELECT new com.example.dto.RrsLayerWithReqAndSchDTO(" +
           "l.reqInfo.reqSeqNo, l.reqInfo.title, l.schInfo.id.makeDegree, l.schInfo.scheduleStatus, " +
           "l.id.layerId, l.layerName) " +
           "FROM RrsLayerInfo l " +
           "JOIN l.reqInfo r " +
           "JOIN l.schInfo s")
    List<RrsLayerWithReqAndSchDTO> findLayerWithReqAndSch();
}
