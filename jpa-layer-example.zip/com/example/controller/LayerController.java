package com.example.controller;

import com.example.dto.RrsLayerWithReqAndSchDTO;
import com.example.service.LayerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/layers")
@RequiredArgsConstructor
public class LayerController {

    private final LayerService layerService;

    @GetMapping
    public ResponseEntity<List<RrsLayerWithReqAndSchDTO>> getLayers() {
        return ResponseEntity.ok(layerService.getLayerInfos());
    }
}
