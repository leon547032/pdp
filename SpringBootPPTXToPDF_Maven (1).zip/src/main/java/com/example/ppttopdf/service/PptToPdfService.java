package com.example.ppttopdf.service;

import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.springframework.stereotype.Service;
import com.itextpdf.kernel.pdf.*;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;

@Service
public class PptToPdfService {

    public ByteArrayOutputStream convertPptToPdf(InputStream pptxStream) throws IOException {
        ByteArrayOutputStream pdfOutputStream = new ByteArrayOutputStream();

        try (XMLSlideShow ppt = new XMLSlideShow(pptxStream);
             PdfWriter writer = new PdfWriter(pdfOutputStream);
             PdfDocument pdf = new PdfDocument(writer);
             Document document = new Document(pdf)) {

            for (XSLFSlide slide : ppt.getSlides()) {
                BufferedImage image = renderSlideWithText(slide, 1280, 720);

                ByteArrayOutputStream imageStream = new ByteArrayOutputStream();
                ImageIO.write(image, "png", imageStream);
                ImageData imageData = ImageDataFactory.create(imageStream.toByteArray());
                Image pdfImage = new Image(imageData);
                document.add(pdfImage);
            }
        }

        return pdfOutputStream;
    }

    private BufferedImage renderSlideWithText(XSLFSlide slide, int width, int height) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics = image.createGraphics();
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics.setPaint(Color.WHITE);
        graphics.fillRect(0, 0, width, height);

        slide.draw(graphics);
        graphics.dispose();
        return image;
    }
}
