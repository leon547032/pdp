package com.example.ppttopdf.controller;

import com.example.ppttopdf.service.PptToPdfService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

@RestController
@RequestMapping("/api/convert")
public class PptToPdfController {

    private final PptToPdfService pptToPdfService;

    public PptToPdfController(PptToPdfService pptToPdfService) {
        this.pptToPdfService = pptToPdfService;
    }

    @PostMapping("/ppt-to-pdf")
    public ResponseEntity<byte[]> convertPptToPdf(@RequestParam("file") MultipartFile file) {
        try {
            ByteArrayOutputStream pdfOutputStream = pptToPdfService.convertPptToPdf(file.getInputStream());
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("filename", "converted.pdf");
            return new ResponseEntity<>(pdfOutputStream.toByteArray(), headers, HttpStatus.OK);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
