package com.example.pptx2pdf.controller;

import com.example.pptx2pdf.service.PptxToPdfService;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;

@RestController
@RequestMapping("/convert")
public class PptxToPdfController {

    private final PptxToPdfService pptxToPdfService;

    public PptxToPdfController(PptxToPdfService pptxToPdfService) {
        this.pptxToPdfService = pptxToPdfService;
    }

    @PostMapping("/pptx-to-pdf")
    public ResponseEntity<ByteArrayResource> convertPptxToPdf(@RequestParam("file") MultipartFile file) {
        try {
            File inputFile = File.createTempFile("input", ".pptx");
            file.transferTo(inputFile);

            return pptxToPdfService.convertPptxToPdf(inputFile);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }
}
