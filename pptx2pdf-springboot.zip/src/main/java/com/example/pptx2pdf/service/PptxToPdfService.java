package com.example.pptx2pdf.service;

import org.jodconverter.DocumentConverter;
import org.jodconverter.remote.RemoteConverter;
import org.jodconverter.remote.office.RemoteOfficeManager;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileInputStream;

@Service
public class PptxToPdfService {

    private static final String LIBRE_OFFICE_URL = "socket,host=your-remote-server,port=8100";

    public ResponseEntity<ByteArrayResource> convertPptxToPdf(File inputFile) {
        try {
            File outputFile = new File(inputFile.getAbsolutePath().replace(".pptx", ".pdf"));

            RemoteOfficeManager officeManager = RemoteOfficeManager.builder()
                    .urlConnection(LIBRE_OFFICE_URL)
                    .build();
            officeManager.start();

            DocumentConverter converter = RemoteConverter.make(officeManager);
            converter.convert(inputFile).to(outputFile).execute();

            officeManager.stop();

            byte[] pdfBytes = new FileInputStream(outputFile).readAllBytes();

            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + outputFile.getName());

            ByteArrayResource resource = new ByteArrayResource(pdfBytes);

            return ResponseEntity.ok()
                    .headers(headers)
                    .contentLength(pdfBytes.length)
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(resource);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }
}
