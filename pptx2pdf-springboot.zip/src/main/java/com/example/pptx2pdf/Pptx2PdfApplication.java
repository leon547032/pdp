package com.example.pptx2pdf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pptx2PdfApplication {
    public static void main(String[] args) {
        SpringApplication.run(Pptx2PdfApplication.class, args);
    }
}
