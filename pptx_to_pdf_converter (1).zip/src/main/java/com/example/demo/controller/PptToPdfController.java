package com.example.demo.controller;

import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.*;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import org.apache.poi.xslf.usermodel.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;

@RestController
@RequestMapping("/api")
public class PptToPdfController {

    @PostMapping("/convert")
    public ResponseEntity<byte[]> convertPptToPdf(@RequestParam("file") MultipartFile file) {
        try {
            // Load PPTX file
            XMLSlideShow ppt = new XMLSlideShow(file.getInputStream());

            // Create PDF document
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            PdfWriter writer = new PdfWriter(outputStream);
            PdfDocument pdfDocument = new PdfDocument(writer);
            Document document = new Document(pdfDocument);

            // Set font (Malgun Gothic)
            String fontPath = "C:/Windows/Fonts/malgun.ttf"; // Windows
            // String fontPath = "/usr/share/fonts/malgun.ttf"; // Linux
            PdfFont font = PdfFontFactory.createFont(fontPath, "Identity-H", true);

            // Convert slides to PDF
            for (XSLFSlide slide : ppt.getSlides()) {
                for (XSLFShape shape : slide.getShapes()) {
                    if (shape instanceof XSLFTextShape) {
                        XSLFTextShape textShape = (XSLFTextShape) shape;
                        for (XSLFTextParagraph paragraph : textShape.getTextParagraphs()) {
                            for (XSLFTextRun run : paragraph.getTextRuns()) {
                                String text = run.getText();
                                if (text != null && !text.isEmpty()) {
                                    Paragraph p = new Paragraph(text)
                                            .setFont(font)
                                            .setFontSize(14)
                                            .setFontColor(ColorConstants.BLACK);
                                    document.add(p);
                                }
                            }
                        }
                    }
                }
                document.add(new Paragraph("\n")); // Slide spacing
            }

            // Save PDF and close resources
            document.close();
            pdfDocument.close();
            ppt.close();

            // Return HTTP response (PDF file download)
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=converted.pdf");
            headers.add(HttpHeaders.CONTENT_TYPE, "application/pdf");

            return new ResponseEntity<>(outputStream.toByteArray(), headers, HttpStatus.OK);

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}
