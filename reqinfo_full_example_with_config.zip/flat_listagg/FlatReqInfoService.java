@Service
@RequiredArgsConstructor
public class FlatReqInfoService {

    private final ReqInfoFlatRepository flatRepository;

    public Page<FlatReqInfoDto> getFlatList(String deviceCd, String revCd, String maskId, Pageable pageable) {
        return flatRepository.fetchFlatListWithListagg(deviceCd, revCd, maskId, pageable);
    }
}
