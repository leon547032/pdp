@RestController
@RequestMapping("/reqs/flat")
@RequiredArgsConstructor
public class FlatReqInfoController {

    private final FlatReqInfoService flatReqInfoService;

    @GetMapping
    public Page<FlatReqInfoDto> getFlatList(
            @RequestParam(required = false) String deviceCd,
            @RequestParam(required = false) String revCd,
            @RequestParam(required = false) String maskId,
            Pageable pageable) {
        return flatReqInfoService.getFlatList(deviceCd, revCd, maskId, pageable);
    }
}
