@RequiredArgsConstructor
public class ReqInfoFlatRepositoryImpl implements ReqInfoFlatRepository {

    private final EntityManager em;

    @Override
    public Page<FlatReqInfoDto> fetchFlatListWithListagg(String deviceCd,
                                                          String revCd,
                                                          String maskId,
                                                          Pageable pageable) {

        String baseSql = """
            SELECT R.REQ_SEQNO,
                   R.MPS_DEVICE_CD,
                   LISTAGG(L.MPS_LAYER_CD, ',') 
                       WITHIN GROUP (ORDER BY L.MPS_LAYER_CD) AS LAYER_CD_LIST
            FROM REQ_INFO R
            LEFT JOIN REQ_SCH_INFO S ON R.REQ_SEQNO = S.REQ_SEQNO
            LEFT JOIN REQ_LAYER_INFO L ON S.REQ_SEQNO = L.REQ_SEQNO AND S.MAKE_DEGREE = L.MAKE_DEGREE
            WHERE (:deviceCd IS NULL OR R.MPS_DEVICE_CD = :deviceCd)
              AND (:revCd IS NULL OR L.MPS_REV_CD = :revCd)
              AND (:maskId IS NULL OR L.MPS_MASK_ID = :maskId)
            GROUP BY R.REQ_SEQNO, R.MPS_DEVICE_CD
            ORDER BY MAX(R.CRT_DT) DESC
            OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY
        """;

        List<Object[]> rows = em.createNativeQuery(baseSql)
                .setParameter("deviceCd", deviceCd)
                .setParameter("revCd", revCd)
                .setParameter("maskId", maskId)
                .setParameter("offset", (int) pageable.getOffset())
                .setParameter("limit", pageable.getPageSize())
                .getResultList();

        List<FlatReqInfoDto> content = rows.stream()
                .map(r -> new FlatReqInfoDto(
                        ((Number) r[0]).longValue(),
                        (String) r[1],
                        (String) r[2]
                ))
                .collect(Collectors.toList());

        String countSql = """
            SELECT COUNT(*) FROM (
              SELECT 1
              FROM REQ_INFO R
              LEFT JOIN REQ_SCH_INFO S ON R.REQ_SEQNO = S.REQ_SEQNO
              LEFT JOIN REQ_LAYER_INFO L ON S.REQ_SEQNO = L.REQ_SEQNO AND S.MAKE_DEGREE = L.MAKE_DEGREE
              WHERE (:deviceCd IS NULL OR R.MPS_DEVICE_CD = :deviceCd)
                AND (:revCd IS NULL OR L.MPS_REV_CD = :revCd)
                AND (:maskId IS NULL OR L.MPS_MASK_ID = :maskId)
              GROUP BY R.REQ_SEQNO, R.MPS_DEVICE_CD
            )
        """;

        Number total = (Number) em.createNativeQuery(countSql)
                .setParameter("deviceCd", deviceCd)
                .setParameter("revCd", revCd)
                .setParameter("maskId", maskId)
                .getSingleResult();

        return new PageImpl<>(content, pageable, total.longValue());
    }
}
