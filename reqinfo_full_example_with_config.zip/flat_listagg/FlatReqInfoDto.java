@Getter
@AllArgsConstructor
public class FlatReqInfoDto {
    private Long reqSeqno;
    private String mpsDeviceCd;
    private String layerCdList;
}
