public interface ReqInfoFlatRepository {
    Page<FlatReqInfoDto> fetchFlatListWithListagg(String deviceCd, String revCd, String maskId, Pageable pageable);
}
