// 이 파일은 QueryDSL 자동 생성된 Q타입 클래스의 예시입니다.
// 실제 사용 시에는 build 시점에 QReqInfo, QReqSchInfo, QReqLayerInfo 등이 생성됩니다.

QReqInfo reqInfo = QReqInfo.reqInfo;
QReqSchInfo reqSchInfo = QReqSchInfo.reqSchInfo;
QReqLayerInfo reqLayerInfo = QReqLayerInfo.reqLayerInfo;
