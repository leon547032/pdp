@Entity
@Getter
@Setter
public class ReqLayerInfo {
    @Id
    private Long id;

    private Long reqSeqno;
    private Integer makeDegree;
    private String mpsLayerCd;
    private String mpsRevCd;
    private String mpsMaskId;

    @ManyToOne
    @JoinColumns({
        @JoinColumn(name = "req_seqno", referencedColumnName = "reqSeqno", insertable = false, updatable = false),
        @JoinColumn(name = "make_degree", referencedColumnName = "makeDegree", insertable = false, updatable = false)
    })
    private ReqSchInfo reqSchInfo;
}
