public interface ReqInfoRepositoryCustom {
    Page<ReqInfoDto> fetchReqInfoWithLayersPaged(String deviceCd, String revCd, String maskId, Pageable pageable);
}
