@Getter
@AllArgsConstructor
public class LayerInfoDto {
    private String mpsLayerCd;
    private String mpsRevCd;
    private String mpsMaskId;
}
