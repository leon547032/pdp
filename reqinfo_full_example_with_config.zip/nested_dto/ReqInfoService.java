@Service
@RequiredArgsConstructor
public class ReqInfoService {

    private final ReqInfoRepositoryCustom repository;

    public Page<ReqInfoDto> getNestedList(String deviceCd, String revCd, String maskId, Pageable pageable) {
        return repository.fetchReqInfoWithLayersPaged(deviceCd, revCd, maskId, pageable);
    }
}
