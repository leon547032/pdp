@Getter
@Setter
@NoArgsConstructor
public class ReqInfoDto {
    private Long reqSeqno;
    private String mpsDeviceCd;
    private List<LayerInfoDto> layerList = new ArrayList<>();

    public ReqInfoDto(Long reqSeqno, String mpsDeviceCd) {
        this.reqSeqno = reqSeqno;
        this.mpsDeviceCd = mpsDeviceCd;
    }
}
