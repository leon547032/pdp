@Entity
@Getter
@Setter
public class ReqSchInfo {
    @Id
    private Long id;

    private Long reqSeqno;

    private Integer makeDegree;

    @ManyToOne
    @JoinColumn(name = "req_seqno", insertable = false, updatable = false)
    private ReqInfo reqInfo;

    @OneToMany(mappedBy = "reqSchInfo")
    private List<ReqLayerInfo> reqLayerInfos;
}
