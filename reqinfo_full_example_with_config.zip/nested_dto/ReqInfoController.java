@RestController
@RequestMapping("/reqs/nested")
@RequiredArgsConstructor
public class ReqInfoController {

    private final ReqInfoService reqInfoService;

    @GetMapping
    public Page<ReqInfoDto> getNestedList(
            @RequestParam(required = false) String deviceCd,
            @RequestParam(required = false) String revCd,
            @RequestParam(required = false) String maskId,
            Pageable pageable) {
        return reqInfoService.getNestedList(deviceCd, revCd, maskId, pageable);
    }
}
