@Entity
@Getter
@Setter
public class ReqInfo {
    @Id
    private Long reqSeqno;

    private String mpsDeviceCd;

    private LocalDateTime crtDt;

    @OneToMany(mappedBy = "reqInfo")
    private List<ReqSchInfo> reqSchInfos;
}
