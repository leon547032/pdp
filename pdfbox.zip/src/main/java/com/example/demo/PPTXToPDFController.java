package com.example.demo;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.List;
import javax.imageio.ImageIO;

@RestController
@RequestMapping("/convert")
public class PPTXToPDFController {

    @PostMapping("/pptx-to-pdf")
    public String convertPPTXToPDF(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return "No file uploaded";
        }

        try (InputStream inputStream = file.getInputStream();
             XMLSlideShow ppt = new XMLSlideShow(inputStream);
             PDDocument pdfDocument = new PDDocument()) {

            Dimension pgsize = ppt.getPageSize();
            List<XSLFSlide> slides = ppt.getSlides();

            for (XSLFSlide slide : slides) {
                BufferedImage img = new BufferedImage(pgsize.width, pgsize.height, BufferedImage.TYPE_INT_RGB);
                Graphics2D graphics = img.createGraphics();
                graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                graphics.setColor(Color.WHITE);
                graphics.fill(new Rectangle2D.Float(0, 0, pgsize.width, pgsize.height));

                slide.draw(graphics);
                graphics.dispose();

                File tempImageFile = File.createTempFile("slide", ".png");
                ImageIO.write(img, "png", tempImageFile);

                PDPage page = new PDPage();
                pdfDocument.addPage(page);

                try (PDPageContentStream contentStream = new PDPageContentStream(pdfDocument, page)) {
                    PDImageXObject image = PDImageXObject.createFromFile(tempImageFile.getAbsolutePath(), pdfDocument);
                    contentStream.drawImage(image, 0, 0, page.getMediaBox().getWidth(), page.getMediaBox().getHeight());
                }

                tempImageFile.delete();
            }

            File outputFile = File.createTempFile("output", ".pdf");
            pdfDocument.save(outputFile);
            return "Converted PDF saved: " + outputFile.getAbsolutePath();
        } catch (IOException e) {
            return "Error processing file: " + e.getMessage();
        }
    }
}
